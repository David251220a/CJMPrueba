<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tmp_apo_Rendicion_Aporte_Importar extends Model
{
    //
    protected $table = 'tmp_apo_Rendicion_Aporte_Importar';

    //protected $table = 'categoria';

    public $timestamps= false;

    protected $guarded = [];

    //protected $primarykey='IdImport';
    //protected $fillable = [];


    //public function getKeyName(){
    //    return "IdImport";
    //}
}
