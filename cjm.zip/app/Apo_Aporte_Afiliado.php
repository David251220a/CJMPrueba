<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Apo_Aporte_Afiliado extends Model
{
    //
    protected $table = 'apo_Aporte_Afiliado';

    //protected $table = 'categoria';

    public $timestamps= false;

    //protected $primarykey='Id_Legajo';


    //public function getKeyName(){
    //    return "Id_Legajo";
    //}
    
}
