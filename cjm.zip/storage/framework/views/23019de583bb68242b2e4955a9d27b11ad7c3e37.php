

<?php $__env->startSection('contenido'); ?>

<div class="rows">

    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">

        <h3>Constancia de Aporte</h3>
        <?php echo $__env->make('constancia.aporte.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>           
        
    </div>

</div>
<br>
<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">

        <?php if(session()->has('msj')): ?>
        <div class="alert alert-info" role="alert"><?php echo e(session('msj')); ?></div>
        <?php else: ?>
        <div class="alert alert-info"  role="alert" style="display:none;"><?php echo e(session('msj')); ?></div>
        <?php endif; ?>                
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/constancia\aporte/index.blade.php ENDPATH**/ ?>