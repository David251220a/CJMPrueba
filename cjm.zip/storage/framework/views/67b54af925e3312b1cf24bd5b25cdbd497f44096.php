

<?php $__env->startSection('contenido'); ?>


<?php  $total_Salario = 0 ?>
<?php  $total_Bonificacion = 0 ?>
<?php  $total_Aporte_Salario = 0 ?>
<?php  $total_Aporte_Bonificacion = 0 ?>
<?php  $totalPrimeraAsif = 0 ?>
<?php  $totalDiferenciaAsif = 0 ?>
<?php  $totalRSA = 0 ?>
<?php  $cantidad = 0 ?>
<?php  $Total_General = 0 ?>


<?php $__currentLoopData = $rendicion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php $total_Salario += $ren->Salario  ?>
    <?php $total_Bonificacion += $ren->Salario_Bonificacion  ?>
    <?php $total_Aporte_Salario += $ren->Aporte_Salario  ?>
    <?php $total_Aporte_Bonificacion += $ren->Aporte_Salario_Bonificacion  ?>
    <?php $totalDiferenciaAsif += $ren->Diferencia_Asignacion  ?>
    <?php $totalPrimeraAsif += $ren->Primera_Asignacion  ?>
    <?php $totalRSA += $ren->RSA  ?>
    <?php $cantidad +=  1  ?>    

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $Total_General = $total_Aporte_Salario + $total_Aporte_Bonificacion + $totalDiferenciaAsif + $totalPrimeraAsif +$totalRSA ?>

    <div class="row">
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <h3>Nueva Planilla</h3>
            
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </ul>

                </div>
                
            <?php endif; ?>
        
        </div>

    </div>

    <div class="rows">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <?php if(session()->has('msj')): ?>
            
            <div class="alert alert-danger" role="alert"><?php echo e(session('msj')); ?></div>
            
            <?php else: ?>
                
            <?php endif; ?>
        </div>
    </div>

    <div class="row">

       
        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

        <div class="form-group">
            <a href="<?php echo e(URL::action('apo_Afiliado_Inst_MunicController@index')); ?>"><button style='width:145px; height:50'  class="btn btn-info">Editar Afiliados</button></a>
        </div>

        </div>    

    </div>

    <?php echo Form::open(array('url'=>'rendicionaporte/generar', 'method'=>'POST', 'autocomplete'=>'off')); ?>

    <?php echo e(Form::token()); ?>


    <div class="row">

       
        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

        <div class="form-group">

            <button class="btn btn-primary" type="submit">Enviar</button>
            <button class="btn btn-danger" type="reset">Cancelar</button>  
        </div>

        </div>    

    </div>    

    <div class="row">

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="fecha" >Fecha de Planilla </label>
                <input style="text-align:right;" type="date" name="fecha" class="form-control" value="2020-01-31">


            </div>
            
        </div>

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="cantidad" >Cantidad de Afiliados</label>
                <input style="text-align:right;" type="text" name="cantidad" value="<?php echo e(number_format($cantidad, 0, ".", ".")); ?>" class="form-control" readonly>

            </div>
            
        </div>

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_salario" >Total Salario </label>
                <input style="text-align:right;" type="text" name="total_salario" value="<?php echo e(number_format($total_Salario, 0, ".", ".")); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_bonificacion" >Total Bonificacion </label>
                <input style="text-align:right;" type="text" name="total_bonificacion" value="<?php echo e(number_format($total_Bonificacion, 0, ".", ".")); ?>" class="form-control" readonly >

            </div>
            
        </div>


        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_aporte" >Total Aporte Salario </label>
                <input style="text-align:right;" type="text" name="total_aporte" value="<?php echo e(number_format($total_Aporte_Salario, 0, ".", ".")); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_aporte_bonificacion" >Total Aporte Bonif. </label>
                <input style="text-align:right;" type="text" name="total_aporte_bonificacion" value="<?php echo e(number_format($total_Aporte_Bonificacion, 0, ".", ".")); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_primera_asig" >Total Primera Asig. </label>
                <input style="text-align:right;" type="text" name="total_primera_asig" value="<?php echo e(number_format($totalPrimeraAsif, 0, ".", ".")); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_diferencia_asig" >Total Diferencia Asig. </label>
                <input style="text-align:right;" type="text" name="total_diferencia_asig"  value="<?php echo e(number_format($totalDiferenciaAsif, 0, ".", ".")); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_rsa" >Total R.S.A. </label>
                <input style="text-align:right;" type="text" name="total_rsa"  value="<?php echo e(number_format($totalRSA, 0, ".", ".")); ?>" class="form-control" readonly>

            </div>
            
        </div>        

        <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">

            <div class="form-group">

                <label for="total_general" >Total General </label>
                <input style="text-align:right;" type="text" name="total_general" class="form-control" value="<?php echo e(number_format($Total_General, 0, ".", ".")); ?>" readonly>


            </div>
            
        </div>

    </div>
        

    <div class="rows">        

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="table-responsive">

                <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">

                    
                    
                    <thead style="background-color:#A9D0F5">

                        <th  hidden></th>
                        <th>Cedula de Identidad</th>
                        <th>Nombre y Apellido</th>                                                                 
                        <th>Salario</th>
                        <th>Salario Bonificacion</th>                        
                        <th>Aporte Salario</th>
                        <th>Aporte Bonficacion</th>
                        <th>Primera Asig</th>
                        <th>Diferencia Asig</th>
                        <th>RSA</th>                      

                    </thead>                    
                    
                    <tbody id="developers">
                        <?php
                        $cont = 0;
                        ?>
                        <?php $__currentLoopData = $rendicion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="select" name="fila[]" id="fila<?php echo e($cont); ?>" >
                                <td hidden><input type="hidden" value="<?php echo e($ren->Id_Afiliado_Institucion); ?>" > </td>
                                <td style="text-align:right;"><input style="text-align:right;" type="text" value="<?php echo e($ren->Documento); ?>" readonly></td>
                                <td style="text-align:right;"><input style="text-align:right;" type="text" value="<?php echo e($ren->Nombre); ?> , <?php echo e($ren->Apellido); ?>" readonly></td>                                                        
                                <td style="text-align:right;"><input style="text-align:right;" type="number" value="<?php echo e($ren->Salario); ?>" readonly></td>
                                <td style="text-align:right;"><input style="text-align:right;" type="number" name="salario_bonificacion[]" value="<?php echo e($ren->Salario_Bonificacion); ?>" readonly></td>
                                <td style="text-align:right;"><input style="text-align:right;" type="number" value="<?php echo e($ren->Aporte_Salario); ?>" readonly></td>
                                <td style="text-align:right;"><input style="text-align:right;" type="number" value="<?php echo e($ren->Aporte_Salario_Bonificacion); ?>" readonly></td>
                                <td style="text-align:right;"><input style="text-align:right;" type="number" value="<?php echo e($ren->Primera_Asignacion); ?>" readonly></td>
                                <td style="text-align:right;"><input style="text-align:right;" type="number" value="<?php echo e($ren->Diferencia_Asignacion); ?>" readonly></td>
                                <td style="text-align:right;"><input style="text-align:right;" type="number" value="<?php echo e($ren->RSA); ?>" readonly></td>
                                
                            </tr>
                            <?php
                            $cont++;
                            ?>
                            <input id="cont" name="cont" value="<?php echo e($cont); ?>" type="hidden"></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <div class="col-md-12 text-center">
                        <ul class="pagination pagination-lg pager" id="developer_page"></ul>
                    </div>
                    
                </table>

            </div>
            

        </div>

    </div>

    <div class="rows">        

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="table-responsive">

                <table id="detalles1" class="table table-striped table-bordered table-condensed table-hover">

                    
                    
                    <thead style="background-color:#A9D0F5">

                        <th  hidden></th>
                        <th hidden></th>
                        <th hidden></th>
                        <th hidden></th>
                        <th hidden></th>                        
                        <th hidden></th>
                        <th hidden></th>
                        <th hidden></th>
                        <th hidden></th>
                        <th hidden></th>                      

                    </thead>                    
                    
                    <tbody>
                        <?php
                        $cont1= 0;
                        ?>
                        <?php $__currentLoopData = $rendicion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $re): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="select" name="fila[]" id="fila<?php echo e($cont1); ?>" >
                                <td hidden><input type="hidden" id="id_afiliado_institucion" name="id_afiliado_institucion[]" value="<?php echo e($re->Id_Afiliado_Institucion); ?>" > </td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="text" id="cedula" name="cedula[]" value="<?php echo e($re->Documento); ?>" readonly></td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="text" id="nombre" name="nombre_apellido[]" value="<?php echo e($re->Nombre); ?> , <?php echo e($re->Apellido); ?>" readonly></td>                                                        
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="number" id="salario" name="salario[]" value="<?php echo e($re->Salario); ?>" readonly></td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="number" id="salario_bonificacion" name="salario_bonificacion[]" value="<?php echo e($re->Salario_Bonificacion); ?>" readonly></td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="number" id="aporte_salario" name="aporte_salario[]" value="<?php echo e($re->Aporte_Salario); ?>" readonly></td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="number" id="aporte_bonificacion" name="aporte_bonificacion[]" value="<?php echo e($re->Aporte_Salario_Bonificacion); ?>" readonly></td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="number" id="primera_asig" name="primera_asig[]"  value="<?php echo e($re->Primera_Asignacion); ?>" readonly></td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="number" id="diferencia_asig" name="diferencia_asig[]"  value="<?php echo e($re->Diferencia_Asignacion); ?>" readonly></td>
                                <td hidden style="text-align:right;"><input style="text-align:right;" type="number" id="rsa" name="rsa[]" value="<?php echo e($re->RSA); ?>" readonly></td>
                                
                            </tr>
                            <?php
                            $cont1++;
                            ?>
                            <input id="cont" name="cont" value="<?php echo e($cont1); ?>" type="hidden"></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
            

        </div>

    </div>
   
    
    <?php echo Form::close(); ?>

    <?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">
            
        $(document).ready(function() {
            var dataTable = $('#detalles').dataTable({
                //$("#detalles_.dataTables_filter").hide();                
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Entradas",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",                    
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
                        
            }); 

            //$(".dataTables_filter").hide();
            //$("#searchbox").keyup(function() {
            //    dataTable.fnFilter(this.value);
            //});    
        });

    </script>

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/rendicionaporte\generar/create.blade.php ENDPATH**/ ?>