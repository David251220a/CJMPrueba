

<?php $__env->startSection('contenido'); ?>
<?php  $total_Aporte = 0 ?>
<?php  $Aporte = 0 ?>
<?php  $DiferenciaAsif = 0 ?>
<?php  $PrimeraAsif = 0 ?>
<?php  $RSA = 0 ?>


<?php $__currentLoopData = $afiliado_constancia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php $Aporte += $afi->Aporte_Personal  ?>
    <?php $DiferenciaAsif += $afi->Diferencia_Asignacion  ?>
    <?php $PrimeraAsif += $afi->Primera_Asignacion  ?>
    <?php $RSA += $afi->RSA  ?>    
    <?php $total_Aporte += ($afi->Aporte_Personal + $afi->Diferencia_Asignacion + $afi->Primera_Asignacion +$afi->RSA) ?>    

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="panel-body">

    <div class="row">

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="form-group">
                <label form="nombre" > <h4> Afiliado :</h4></label>
                <br>
                <label> <h5> <b><?php echo e($afiliado->Nombre); ?>, <?php echo e($afiliado->Apellido); ?> </b> </h5> </label>
            </div>
        </div>


        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label form="nombre" > <h4> Institucion Municipal :</h4></label>
                <br>
                <label> <h5> <b><?php echo e($afiliado_cabezera->Grupo); ?> </b> </h5> </label>

            </div>
        
        </div>

    </div>


</div>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

        <div class="table-responsive">

            <table class="table table-striped table-bordered table-condensed table-hover">

                
                
                <thead>
                    
                    <th style="text-align: center">Fecha Ultimo Aporte</th>                                                
                    <th style="text-align: center">Total Aporte Personal</th>                    
                    <th style="text-align: center">Total Primera Asig.</th>
                    <th style="text-align: center">Total Diferencia Asig.</th>
                    <th style="text-align: center">Total RSA</th>                    
                    <th style="text-align: center">Antiguedad</th>                    

                </thead>
                

                
                                
                <tr style="vertical-align: middle ; text-align: center">
                    
                    <td><?php echo e(date('d-m-Y', strtotime($afiliado_cabezera->Fecha_Aporte_Ultimo))); ?></td>                                            
                    <td><?php echo e(number_format($afiliado_cabezera->Total_Aporte_Personal,0, ".", ".")); ?></td>                    
                    <td><?php echo e(number_format($afiliado_cabezera->Total_Primera_Asignacion,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($afiliado_cabezera->Total_Diferencia_Asignacion,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($afiliado_cabezera->Total_RSA_Deuda,0, ".", ".")); ?></td>                    
                    <td><?php echo e($afiliado_cabezera->Antiguedad_Año); ?> años y <?php echo e($afiliado_cabezera->Antiguedad_Mes); ?> meses.</td>
                   
                </tr>                            
                
            </table>

        </div>        

    </div>

</div>

<div class="panel-body">

    <div class="row">

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="form-group">
                <label form="nombre" > <h4> CONSTANCIA DE APORTE :</h4></label>
                <br>                
            </div>
        </div>


    </div>


</div>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

        <div class="table-responsive">

            <table class="table table-striped table-bordered table-condensed table-hover">

                
                
                <thead>
                    
                    <th style="text-align: center">Fecha Aporte</th>                                                
                    <th style="text-align: center">Aporte Personal</th>                    
                    <th style="text-align: center">Primera Asig.</th>
                    <th style="text-align: center">Diferencia Asig.</th>
                    <th style="text-align: center">RSA</th>
                    <th style="text-align: center">Tipo Operacion</th>                    

                </thead>
                

                
                                
                <?php $__currentLoopData = $afiliado_constancia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="vertical-align: middle ; text-align: center">
                                
                        <td><?php echo e(date('d-m-Y', strtotime($cons->Fecha_Aporte))); ?></td>                                          
                        <td><?php echo e(number_format($cons->Aporte_Personal,0, ".", ".")); ?></td>                    
                        <td><?php echo e(number_format($cons->Primera_Asignacion,0, ".", ".")); ?></td>
                        <td><?php echo e(number_format($cons->Diferencia_Asignacion,0, ".", ".")); ?></td>
                        <td><?php echo e(number_format($cons->RSA,0, ".", ".")); ?></td>
                        <td><?php echo e($cons->Desc_Tipo_Operacion); ?> </td>
                                   
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr style="vertical-align: middle ; text-align: center">
                    <td> <b> TOTALES </b> </td>                                            
                    <td> <b> <?php echo e(number_format($Aporte,0, ".", ".")); ?> </b> </td>                    
                    <td> <b> <?php echo e(number_format($PrimeraAsif,0, ".", ".")); ?> </b> </td>
                    <td> <b> <?php echo e(number_format($DiferenciaAsif,0, ".", ".")); ?> </b> </td>
                    <td> <b> <?php echo e(number_format($RSA,0, ".", ".")); ?> </b> </td>
                    <td> <b> <?php echo e(number_format($total_Aporte,0, ".", ".")); ?> TOTAL GENERAL </b> </td>

                </tr>
            </table>

        </div>         

    </div>    

</div>


<div class="row">
       
    <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

        <div class="form-group">
        <a href="<?php echo e(URL::action('PDFController@ConstanciaAporte', $afiliado->Id_Legajo)); ?>" target="_blank">
            <button class="btn btn-info">PDF</button>
        </a>
                
        <button class="btn btn-danger" onclick="history.back()">Atras</button>  

        

        </div>

    </div>    

</div>


   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/constancia\aporte/show.blade.php ENDPATH**/ ?>