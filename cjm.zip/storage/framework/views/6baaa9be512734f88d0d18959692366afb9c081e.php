

<?php $__env->startSection('contenido'); ?>

    <div class="row">

        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

            <LEGEND><b> <i> <u><h3> <?php echo e($contenido->Titulo); ?></h3></u></i></b> </LEGEND>
            <label for=""><?php echo e($contenido->Descripcion); ?> </label>

        </div>

        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

            <br><br>
            
            <div class="video-responsive" >
                <div style="text-align: center">
                    <iframe src="<?php echo e($contenido->Video); ?>" frameborder="0" allowfullscreen  width="560" height="315"></iframe>
                </div>
            </div>

        </div>    
    </div>

    <div class="row">
    
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <br>
            <br>
            <p><label for=""><?php echo e($contenido->Contenido); ?></label>
                <a href="<?php echo e($contenido->Enlaces); ?>" target="_blank">
                    descargar.</a> 
            </p>
            

        </div>    
        

    </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/ayuda/show.blade.php ENDPATH**/ ?>