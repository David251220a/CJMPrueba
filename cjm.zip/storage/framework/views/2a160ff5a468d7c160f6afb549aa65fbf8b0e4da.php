<div class="rows">
    <h3 style="text-align: center">INSTITUCION DE : <?php echo e($planilla->name); ?></h3>
    <h4 style="text-align: center"> PLANILLA MENSUAL DE APORTE CON FECHA DE: <?php echo e($planilla->Fecha_Planilla); ?></h4>

    <br>
</div><?php /**PATH C:\laragon\www\cjm\resources\views/pdf\planillamensual\planillaImportPDF.blade.php ENDPATH**/ ?>