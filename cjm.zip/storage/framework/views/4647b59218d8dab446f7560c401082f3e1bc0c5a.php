

<?php $__env->startSection('contenido'); ?>

<?php  $total_general = 0 ?>
<?php  $Monto_Cuota_Saldo = 0 ?>
<?php  $Monto_Cuota_Interes_Saldo = 0 ?>
<?php  $Monto_Cuota_Amortizacion_Saldo = 0 ?>
<?php  $MontoCuota_Interes_Punitorio_Saldo = 0 ?>
<?php  $MontoCuota_Interes_Punitorio_Congelado = 0 ?>
<?php  $Monto_Cuota_Seguro_Saldo = 0 ?>
<?php  $Monto_IVA = 0 ?>


<?php  $Aporte_Total_General = 0 ?>
<?php  $Prestamos_Total_General = 0 ?>
<?php  $Total_General_Deuda = 0 ?>
<?php  $Total_Disponible = 0 ?>
<?php  $Texto_Obserbacion = "" ?>
<?php  $existe_pedido = 0 ?>

<?php if(empty($pedido_refinanciacion->Descripcion)): ?>
    
    <?php  $Texto_Obserbacion = "Yo autorizo el refinanción de mis deudas(Activo o Moroso) con un total de #.###.### a un plazo de ## meses" ?>
    <?php  $existe_pedido = 0 ?>

<?php else: ?>
    
    <?php  $Texto_Obserbacion = $pedido_refinanciacion->Descripcion ?>
    <?php  $existe_pedido = 1 ?>

<?php endif; ?>


<?php if(empty($aux_prestamo_morosidad->cant)): ?>

<?php else: ?>

    <?php $__currentLoopData = $prestamo_morosidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pre_mor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $Monto_Cuota_Saldo += $pre_mor->Monto_Cuota_Saldo  ?>
        <?php $Monto_Cuota_Interes_Saldo += $pre_mor->Monto_Cuota_Interes_Saldo  ?>
        <?php $Monto_Cuota_Amortizacion_Saldo += $pre_mor->Monto_Cuota_Amortizacion_Saldo  ?>
        <?php $MontoCuota_Interes_Punitorio_Saldo += $pre_mor->MontoCuota_Interes_Punitorio_Saldo  ?>
        <?php $MontoCuota_Interes_Punitorio_Congelado += $pre_mor->MontoCuota_Interes_Punitorio_Congelado  ?>
        <?php $Monto_Cuota_Seguro_Saldo += $pre_mor->Monto_Cuota_Seguro_Saldo  ?>
        <?php $Monto_IVA += $pre_mor->IVA  ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>


<?php $total_general = $Monto_Cuota_Interes_Saldo 
                    + $Monto_Cuota_Amortizacion_Saldo 
                    + $MontoCuota_Interes_Punitorio_Saldo 
                    + $MontoCuota_Interes_Punitorio_Congelado 
                    + $Monto_Cuota_Seguro_Saldo 
                    + $Monto_IVA                 
?>

<?php if(empty($aux_aporte->cant)): ?>

    <?php
        
        $Aporte_Total_General =52628136

    ?> 

<?php else: ?>

    <?php  $Aporte_Total_General = $aporte->Total_Aporte_Personal 
                                + $aporte->Total_Primera_Asignacion 
                                + $aporte->Total_Diferencia_Asignacion 
                                + $aporte->Total_RSA_Deuda

    ?>

<?php endif; ?>

<?php if(empty($aux_prestamo->cant)): ?>

<?php else: ?>

    <?php $__currentLoopData = $prestamo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $Prestamos_Total_General += $pre->Monto_Amortizacion_Total_SaldoActual  ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

<?php endif; ?>

<?php
    
    $Total_General_Deuda = $Prestamos_Total_General + $total_general    

?>

<?php

    $Total_Disponible = $Aporte_Total_General -  $Total_General_Deuda

?>

    <div class="panel-body">

        <div class="row">

            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                    <label form="nombre" > <h4> Afiliado :</h4></label>
                    <br>
                    <label> <h4> <b><?php echo e($afiliado->Nombre); ?>, <?php echo e($afiliado->Apellido); ?> </b> </h4> </label>
                    
                </div>
            </div>


            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

                <div class="form-group">

                    <label form="nombre" > <h4> Institucion Municipal :</h4></label>
                    <br>
                    <label> <h5> <b><?php echo e($institucion_municipal->NombreInstitucionMunicipal); ?></b> </h5> </label>

                </div>
            
            </div>

        </div>

    </div>

    <?php if(empty($aux_aporte->cant)): ?>

    <?php else: ?>

        <LEGEND><b> <i> <u><h3> TOTAL DE  APORTE</h3></u></i></b> </LEGEND>

        <div class="rows">

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        
                <div class="table-responsive">
        
                    <table class="table table-striped table-bordered table-condensed table-hover">
        
                        
                        
                        <thead>
                            
                            <th style="text-align: center">Fecha Ultimo Aporte</th>                                                
                            <th style="text-align: center">Total Aporte Personal</th>                    
                            <th style="text-align: center">Total Primera Asig.</th>
                            <th style="text-align: center">Total Diferencia Asig.</th>
                            <th style="text-align: center">Total RSA</th>
                            <th style="text-align: center">Total General</th>
                            <th style="text-align: center">Antiguedad</th>                    
        
                        </thead>                        
                                        
                        <tr style="vertical-align: middle ; text-align: center">
                            
                            <td><?php echo e(date('d-m-Y', strtotime($aporte->Fecha_Aporte_Ultimo))); ?></td>                                            
                            <td><?php echo e(number_format($aporte->Total_Aporte_Personal,0, ".", ".")); ?></td>                    
                            <td><?php echo e(number_format($aporte->Total_Primera_Asignacion,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($aporte->Total_Diferencia_Asignacion,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($aporte->Total_RSA_Deuda,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($Aporte_Total_General,0, ".", ".")); ?></td>
                            <td><?php echo e($aporte->Antiguedad_Año); ?> años y <?php echo e($aporte->Antiguedad_Mes); ?> meses.</td>
                        
                        </tr>                            
                        
                    </table>
        
                </div>        
        
            </div>
    
        </div>
    
    <?php endif; ?>
    
    <?php if(empty($aux_prestamo->cant)): ?>

    <?php else: ?>
        <div class="rows">

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        
                <FIELDSET>
        
                    <LEGEND><b> <i> <u><h3> PRESTAMOS ACTIVOS</h3></u></i></b> </LEGEND>
        
                    <div class="table-responsive">
        
                        <table id="detalles"  class="table table-striped table-bordered table-condensed table-hover">                            
                            
                            <thead>
                                
                                <th style="text-align: center">Secuencia</th>
                                <th style="text-align: center">Cuota / Plazo</th>
                                <th style="text-align: center">Monto Prestamo</th>                    
                                <th style="text-align: center">Monto Cuota</th>
                                <th style="text-align: center">Fecha Ult/Generacion</th>
                                <th style="text-align: center">Saldo Actual</th>                    
                                <th style="text-align: center">Linea</th>
                                <th style="text-align: center">Dependencia</th>
        
                            </thead>                    
                                
                            <?php $__currentLoopData = $prestamo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                                <tr style="vertical-align: middle ; text-align: center">
                            
                                    <td><?php echo e($cons->Secuencia); ?></td>                         
                                    <td><?php echo e($cons->Cuota_Cobro_Ultimo); ?> / <?php echo e($cons->Plazo); ?></td>                    
                                    <td><?php echo e(number_format($cons->Monto_Prestamo,0, ".", ".")); ?></td>
                                    <td><?php echo e(number_format($cons->Monto_Cuota,0, ".", ".")); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($cons->Cuota_Fecha_Generacion_Ultima))); ?></td>
                                    <td><?php echo e(number_format($cons->Monto_Amortizacion_Total_SaldoActual, 0, ".", ".")); ?></td>
                                    <td><?php echo e($cons->Desc_Producto); ?> </td>
                                    <td><?php echo e($cons->Id_Dependencia); ?> </td> 
                                            
                                </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                            <div class="col-md-12 text-center">
                                <ul class="pagination pagination-lg pager" id="developer_page"></ul>
                            </div>
                        </table>
        
                    </div>
        
                </FIELDSET>
        
            </div>
    
        </div>

    <?php endif; ?>

    <?php if(empty($aux_prestamo_morosidad->cant)): ?>

    <?php else: ?>
        
        <div class="rows">

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        
                <LEGEND><b> <i> <u><h3> MOROSIDAD</h3></u></i></b> </LEGEND>

                <div class="table-responsive">

                    <table class="table table-striped table-bordered table-condensed table-hover">
                        
                        <thead>
                            
                            <th colspan="8" style="text-align: center" >TOTALES</th>

                        </thead>                    

                        <thead>
                            
                            <th style="text-align: center">Monto Cuota Saldo</th>
                            <th style="text-align: center">Monto Interes Saldo</th>
                            <th style="text-align: center">Monto Capital Saldo</th>                    
                            <th style="text-align: center">Monto Int. Punitorio Saldo</th>
                            <th style="text-align: center">Monto Int. Punitorio Congelado Saldo</th>
                            <th style="text-align: center">Monto Seguro Saldo</th>                    
                            <th style="text-align: center">Monto IVA</th>
                            <th style="text-align: center">Total General</th>

                        </thead>                    

                        <tr style="vertical-align: middle ; text-align: center">
                    
                            <td><?php echo e(number_format($Monto_Cuota_Saldo,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($Monto_Cuota_Interes_Saldo,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($Monto_Cuota_Amortizacion_Saldo,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($MontoCuota_Interes_Punitorio_Saldo,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($MontoCuota_Interes_Punitorio_Congelado,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($Monto_Cuota_Seguro_Saldo,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($Monto_IVA,0, ".", ".")); ?></td>
                            <td><?php echo e(number_format($total_general,0, ".", ".")); ?></td> 
                                    
                        </tr>                                               
                        
                    </table>

                </div>

        
            </div>
    
        </div>

    <?php endif; ?>

    <div class="rows">
    
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <LEGEND><b> <i> <u><h3> CAPACIDAD</h3></u></i></b> </LEGEND>            

        </div>

    </div>
    
    <div class="rows">
    
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            
            <label> <h4> <b>Total Aporte: <?php echo e(number_format($Aporte_Total_General,0, ".", ".")); ?></b> </h4> </label>

        </div>
        
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            
            <label> <h4> <b>Total Deuda + Prestamos: <?php echo e(number_format($Total_General_Deuda,0, ".", ".")); ?></b> </h4> </label>

        </div>

        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            
            <label> <h4> <b>Disponibilidad de Prestamos: <?php echo e(number_format($Total_Disponible,0, ".", ".")); ?></b> </h4> </label>

        </div>
    
    </div>

    <div class="rows">
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                  
        
            <div class="checkbox">
                
                <label>
                    <input type="checkbox" id="prefinanciar" value="option1" onchange="showContent()">  Desea Autorizar una Refinanciación para su proxima Solicitud?
                </label>
            </div>
        
        </div>        

    </div>
    <?php echo Form::open(array('url'=>'afiliado/capacidad', 'method'=>'POST', 'autocomplete'=>'off')); ?>

    <?php echo e(Form::token()); ?>    
    <div class="rows">
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                  
    
            <div class="form-group green-border-focus">
                <label style="display:none;" id="pobserbacion1" for="exampleFormControlTextarea5">OBSERBACION</label>
                <textarea style="display:none;" class="form-control" name="pobserbacion" id="pobserbacion" rows="3" ><?php echo e($Texto_Obserbacion); ?></textarea>
            </div>

            <input type="hidden" name="id_legajo" id="id_legajo"  value="<?php echo e($afiliado->Id_Legajo); ?>" class="form-control" >
            <input type="hidden" name="existe_pedido" id="existe_pedido"  value="<?php echo e($existe_pedido); ?>" class="form-control" >
    
        </div>
    </div>
    
    <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

        <div class="form-group">
        <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden" > 
            <button class="btn btn-primary" style="display: none;" id="pguardar" type="submit">Guardar</button>            

        </div>

    </div>    

    <?php echo Form::close(); ?>


    <?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">
            
        $(document).ready(function() {
            var dataTable = $('#detalles').dataTable({
                //$("#detalles_.dataTables_filter").hide();                
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Entradas",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",                    
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
                        
            });

            
            
        });

        function showContent() {
            var observacion = document.getElementById("pobserbacion");
            var observacion1 = document.getElementById("pobserbacion1");
            var check = document.getElementById("prefinanciar");
            var guardar = document.getElementById("pguardar");
            var existe_pedido = document.getElementById("existe_pedido").value;;
            

            if (check.checked) {
                
                if (existe_pedido == 1){
                    
                    observacion.style.display='block';
                    observacion1.style.display='block';
                    alert("Ya cuenta con solicitud de Refinancion.");

                }else{                                
                    observacion.style.display='block';
                    observacion1.style.display='block';
                    guardar.style.display='block';
                
                }  
                
            }else {

                observacion.style.display='none';
                observacion1.style.display='none';
                guardar.style.display='none';
            
            }
            
        }

    </script>


    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\JuegosySofwareinstalado\laragon\www\cjm\resources\views/afiliado\capacidad/index.blade.php ENDPATH**/ ?>