<?php echo Form::open(array('url'=>'afiliado/personainactiva', 'method'=>'GET', 'autocomplete'=>'off', 'role'=>'search')); ?>


<div class="form-group">

    <div class="input-group">

    <input type="search" class="form-control" name="searchtext" placeholder="Buscar.." value="<?php echo e($searchtext); ?>">
    
    <span class="input-group-btn">
        <button type="submit" class="btn btn-primary">Buscar</button>
    </span>

    </div>

</div>

<?php echo e(Form::close()); ?><?php /**PATH E:\JuegosySofwareinstalado\laragon\www\cjm\resources\views/afiliado/personainactiva/search.blade.php ENDPATH**/ ?>