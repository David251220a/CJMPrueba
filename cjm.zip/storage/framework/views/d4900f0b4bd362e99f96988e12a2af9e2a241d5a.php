

<?php $__env->startSection('contenido'); ?>

<div class="rows">

    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 ">

        <h3>Rendición de Aportes Realizadas <a href="generar/create"> <button class="btn btn-success"> Nueva Rendicion </button></a></h3>
                
    </div>

</div>

    <div class="rows">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="table-responsive">

                <table class="table table-striped table-bordered table-condensed table-hover">

                    
                    
                    <thead>
                        
                        <th>Fecha Planilla</th>                                                
                        <th>Total Aporte</th>
                        <th>Total Aporte Bonif.</th>
                        <th>Total Primera Asig.</th>
                        <th>Total Diferencia Asig.</th>
                        <th>Total RSA</th>
                        <th>Situacion</th>
                        <th>Opciones</th>

                    </thead>
                    

                    
                    
                    <?php $__currentLoopData = $rendicion_aporte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="vertical-align: middle ; text-align: center">
                        
                        <td><?php echo e(date('d-m-Y', strtotime($ren->Fecha_Aporte))); ?></td>                                            
                        <td><?php echo e(number_format($ren->Total_Aporte_Personal,0, ".", ".")); ?></td>
                        <td><?php echo e(number_format($ren->Total_Aporte_Bonificacion,0, ".", ".")); ?></td>
                        <td><?php echo e(number_format($ren->Total_Primera_Asignacion,0, ".", ".")); ?></td>
                        <td><?php echo e(number_format($ren->Total_Diferencia_Asignacion,0, ".", ".")); ?></td>
                        <td><?php echo e(number_format($ren->Total_RSA,0, ".", ".")); ?></td>
                        <td><?php echo e($ren->Desc_Situacion); ?></td>
                        <td>
                         
                         
                            <a href="<?php echo e(URL::action('apo_Rendicion_AporteController@show', $ren->Id_Rendicion)); ?>">
                                 <button class="btn btn-info">Detalles</button>
                            </a>
                            
                        </td>
                    </tr>

                    

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>

            </div>

            <?php echo e($rendicion_aporte-> render()); ?>


        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/rendicionaporte\generar/index.blade.php ENDPATH**/ ?>