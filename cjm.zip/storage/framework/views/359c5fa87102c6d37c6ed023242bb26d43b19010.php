

<?php $__env->startSection('contenido'); ?>

<div class="row">
        
    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">

    <h3>Planilla Mensual de la Fecha de : <?php echo e(date('d/m/Y', strtotime($planilla->Fecha_Planilla))); ?></h3>
    

</div>

<div class="row">


    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="cantidad" >Cantidad de Afiliados</label>
            <input type="text" name="cantidad" value="<?php echo e($planilla->Cantidad_Funcionario); ?>" class="form-control" readonly>

        </div>
        
    </div>

    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="total_aporte" >Total Aporte </label>
            <input type="text" name="total_aporte" value="<?php echo e($planilla->Total_Aporte); ?>" class="form-control" readonly >

        </div>
        
    </div>

    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="total_primera_asig" >Total Primera Asignacion </label>
            <input type="text" name="total_primera_asig" value="<?php echo e($planilla->Total_PrimeraAsig); ?>" class="form-control" readonly >

        </div>
        
    </div>

    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="total_diferencia_asig" >Total Diferencia Asignacion </label>
            <input type="text" name="total_diferencia_asig"  value="<?php echo e($planilla->Total_DiferenciaAsig); ?>" class="form-control" readonly >

        </div>
        
    </div>

    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="total_rsa" >Total R.S.A. </label>
            <input type="text" name="total_rsa"  value="<?php echo e($planilla->Total_RSA); ?>" class="form-control" readonly>

        </div>
        
    </div>

    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="total_aporte_sinboni" >Total Aporte sin Bonificacion </label>
            <input type="text" name="total_aporte_sinboni" value="<?php echo e($planilla->Total_Aporte); ?>" class="form-control" readonly>

        </div>
        
    </div>

    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="total_bonificacion" >Total Bonificacion </label>
            <input type="text" name="total_bonificacion" value="<?php echo e($planilla->Total_Bonificacion); ?>" class="form-control" readonly >

        </div>
        
    </div>

    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">

        <div class="form-group">

            <label for="total_bonificacion" >Total General </label>
            <input type="text" name="total_bonificacion" value="<?php echo e($planilla->Total_General); ?>" class="form-control" readonly >

        </div>
        
    </div>

</div>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

        <div class="table-responsive">

            <table class="table table-striped table-bordered table-condensed table-hover">

                
                
                <thead>

                    <th>Cedula de Identidad</th>
                    <th>Nombre</th>                        
                    <th>Apellido</th>
                    <th>Tipo de Aporte</th>
                    <th>Salario</th>
                    <th>Aporte</th>
                    <th>Primera Asig</th>
                    <th>Diferencia Asig</th>
                    <th>RSA</th>
                  

                </thead>
                

                
           
                <?php $__currentLoopData = $planilla_detalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="select">
                        <td><input type="text" id="cedula" name="cedula[]" value="<?php echo e($pla->Cedula); ?>" readonly></td>
                        <td><input type="text" id="nombre" name="nombre[]" value="<?php echo e($pla->Nombre); ?>" readonly></td>                    
                        <td><input type="text"  id="apellido" name="apellido[]" value="<?php echo e($pla->Apellido); ?>" readonly></td>
                        <td><input type="hidden" name="idtipo_aporte[]" value="<?php echo e($pla->IdTipo_Aporte); ?>" ><?php echo e($pla->Tipo_Aporte_Descripcion); ?></td>
                        <td><input type="number" id="salario" name="salario[]" value="<?php echo e($pla->Salario); ?>" readonly></td>
                        <td><input type="number" id="aporte" name="aporte[]" value="<?php echo e($pla->Aporte); ?>" readonly></td>
                        <td><input type="number" id="primera_asig" name="primera_asig[]"  value="<?php echo e($pla->Primera_Asignacion); ?>" readonly></td>
                        <td><input type="number" id="diferencia_asig" name="diferencia_asig[]"  value="<?php echo e($pla->Diferencia_Asignacion); ?>" readonly></td>
                        <td><input type="number" id="rsa" name="rsa[]" value="<?php echo e($pla->RSA); ?>" readonly></td>
                        
                    </tr>
        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </table>

        </div>
        <?php echo e($planilla_detalle-> render()); ?>


    </div>

</div>



<div class="row">

   
    <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

    <div class="form-group">
        <a href="<?php echo e(URL::action('PlanillaMensualPDF@GenerarImport', $planilla->IdItem)); ?>">
            <button class="btn btn-info">PDF</button>
       </a>
        <button class="btn btn-danger">Atras</button>  
    </div>

    </div>    

</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/planillamensual\importar/show.blade.php ENDPATH**/ ?>