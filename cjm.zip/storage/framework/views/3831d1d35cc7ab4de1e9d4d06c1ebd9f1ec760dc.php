

<?php $__env->startSection('contenido'); ?>

    <?php if(session()->has('msj')): ?>
    <div class="alert alert-danger" role="alert"><?php echo e(session('msj')); ?></div>
    <?php else: ?>
        
    <?php endif; ?>


    <div class="row">
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <h3>Nueva Planilla de <?php echo e($institucion_municipal->NombreInstitucionMunicipal); ?></h3>
            
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>
                      
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </ul>

                </div>
                
            <?php endif; ?>
        
        </div>

    </div>

    <?php echo Form::open(array('url'=>'rendicionaporte/importar', 'method'=>'POST', 'autocomplete'=>'off','file'=>'true', 'enctype'=>"multipart/form-data")); ?>

    <?php echo e(Form::token()); ?>



    <div class="row">

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="excel" >Seleccionar Archivo Excel</label>
                <input type="file" name="excel" class="form-control" required>

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">
    
                <label for="fecha" >Seleccionar Fecha Aporte</label>
                <input type="date" name="fecha" class="form-control" value="2020-01-31" required>
    
            </div>
            
        </div>

    </div>


    

    <div class="row">

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

            <div class="form-group">

                <button class="btn btn-primary" type="submit">Enviar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>  
            </div>

        </div>    

    </div>
    
    <?php echo Form::close(); ?>


    <div class="row">
        
        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

            <div class="form-group">
                <a href="#">
                    <button class="btn btn-info" style='width:145px; height:50'>Excel de Ayuda</button>
               </a>
            </div>
    
            </div>    

    </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/rendicionaporte\importar/create.blade.php ENDPATH**/ ?>