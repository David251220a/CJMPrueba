

<?php $__env->startSection('contenido'); ?>

<div class="rows">

    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">

        <h3>Resumen Cobros de Aportes</h3>
        <br>
        <?php echo $__env->make('resumen.aporte.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>           
        
    </div>

</div>

<div class="rows">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

        <div class="table-responsive">

            <table class="table table-striped table-bordered table-condensed table-hover">

                
                
                <thead>

                    <th>Departamento</th>
                    <th>Institución</th>
                    <th>Periodo Pago Personal</th>
                    <th>Periodo Pago Patronal</th>
                    <th>Total Salario</th>
                    <th>Total Personal</th>
                    <th>Total Patronal</th>
                    <th>Total Primera Asig.</th>
                    <th>Total Diferencia Asig.</th>
                    <th>Total RSA</th>
                    <th>Total Aporte</th>                    

                </thead>

                <?php $__currentLoopData = $aporte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><?php echo e($apo->Id_Departamento); ?> - <?php echo e($apo->Desc_Departamento); ?></td>
                    <td><?php echo e($apo->Id_InstitucionMunicipal); ?> - <?php echo e($apo->NombreInstitucionMunicipal); ?></td>
                    <td><?php echo e($apo->Periodo_Aporte_Personal); ?></td>                    
                    <td><?php echo e($apo->Periodo_Aporte_Patronal); ?></td>
                    <td><?php echo e(number_format($apo->Total_Salario,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($apo->Total_Aporte_Personal,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($apo->Total_Aporte_Patronal,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($apo->Total_Primera_Asignacion,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($apo->Total_Diferencia_Asignacion,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($apo->Total_RSA,0, ".", ".")); ?></td>
                    <td><?php echo e(number_format($apo->Total_Aporte,0, ".", ".")); ?></td>

                </tr>               

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </table>

        </div>

        <?php echo e($aporte->render()); ?>


    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/resumen\aporte/index.blade.php ENDPATH**/ ?>