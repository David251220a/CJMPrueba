
<div class="rows">
    <h3 style="text-align: center">INSTITUCION DE : <?php echo e($planilla->name); ?></h3>
    <h4 style="text-align: center"> PLANILLA MENSUAL DE APORTE CON FECHA DE: <?php echo e($planilla->FechaPlanilla); ?></h4>

    <br>
</div>

<div class="rows">

    <div class="panel panel-primary">

        <div class="panel-body">
            
            <div class="rows">

                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

                    <div class="form-group">

                    <label for="text" >Total de Aporte : <b> <?php echo e($planilla->TotalAporte); ?> </b></label> 
                    

                </div>

                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

                    <div class="form-group">

                    <label for="text" >Cantidad de Persona : <b> <?php echo e($planilla->Cantidad); ?> </b></label> 
                    

                </div>
            </div>

        </div>
    
    </div>

    <div class="rows">

        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <table class="table table-striped">

                <thead style="background-color:#A9D0F5">

                    <th>Nro</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Tipo de Aporte</th>
                    <th>Salario</th>
                    <th>Aporte</th>
                    <th>Primera Asignacion</th>
                    <th>Diferencia Aignacion</th>
                    <th>RSA</th>

                </thead>

                
                <tfoot>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                   
                </tfoot>

                <tbody>

                <?php $__currentLoopData = $planilla_detalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($pla->cant); ?></td>
                        <td> <?php echo e($pla->nombre); ?></td>
                        <td> <?php echo e($pla->apellido); ?>"</td>
                        <td> <?php echo e($pla->TipoAporte_Descripcion); ?>"</td>
                        <td> <?php echo e($pla->Salario); ?></td>
                        <td> <?php echo e($pla->Aporte); ?>"</td>
                        <td> <?php echo e($pla->Primera_Asignacion); ?></td>
                        <td> <?php echo e($pla->Diferencia_Asignacion); ?></td>
                        <td> <?php echo e($pla->RSA); ?></td>
                    </tr>
                        

                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 

                </tbody>
            </table>
        </div>
        </div>
<?php /**PATH C:\laragon\www\cjm\resources\views/pdf\planillamensual\planillaPDF.blade.php ENDPATH**/ ?>