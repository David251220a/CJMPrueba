

<?php $__env->startSection('contenido'); ?>
    
    <?php $__currentLoopData = $contenido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <div class="row">

        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

            <LEGEND><b> <i> <u><h3> <?php echo e($contenido->Titulo); ?></h3></u></i></b> </LEGEND>
            <label for=""><?php echo e($contenido->Descripcion); ?> </label>

        </div>

    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/ayuda\index.blade.php ENDPATH**/ ?>