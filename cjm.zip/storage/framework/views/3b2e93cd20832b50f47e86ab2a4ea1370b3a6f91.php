

<?php $__env->startSection('contenido'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/ayuda\ayuda.blade.php ENDPATH**/ ?>