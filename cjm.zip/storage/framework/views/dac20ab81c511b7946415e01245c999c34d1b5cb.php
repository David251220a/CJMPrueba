

<?php $__env->startSection('contenido'); ?>

<div class="rows">

    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 ">

        <h3>Listado de Funcionarios  <a href="persona/create"> <button class="btn btn-success"> Nuevo </button></a></h3>
        <?php echo $__env->make('afiliado.persona.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>

</div>

    <div class="rows">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="table-responsive">

                <table class="table table-striped table-bordered table-condensed table-hover">

                    
                    
                    <thead>

                        <th>Numero Documento</th>
                        <th>Nombre</th>
                        <th>Apellido</th>                        
                        <th>N. Celular</th>                        
                        <th>Opciones</th>

                    </thead>
                                        
                    <?php $__currentLoopData = $afiliado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($afi->Documento); ?></td>
                        <td><?php echo e($afi->Nombre); ?></td>
                        <td><?php echo e($afi->Apellido); ?></td>                    
                        <td><?php echo e($afi->Celular); ?></td>                        
                        <td>
                            <a href="<?php echo e(URL::action('apo_Afiliado_Inst_MunicController@edit', $afi->Id_Legajo)); ?>">
                                 <button class="btn btn-info">Editar</button>
                            </a>
                           
                        <a href="" data-target="#modal-delete-<?php echo e($afi->Id_Afiliado_Institucion); ?>" data-toggle="modal">
                            <button class="btn btn-danger">Borrar</button>
                        </a>
                           
                        </td>
                    </tr>

                    <?php echo $__env->make('afiliado.persona.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>

            </div>

            <?php echo e($afiliado -> render()); ?>


        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/afiliado\persona/index.blade.php ENDPATH**/ ?>