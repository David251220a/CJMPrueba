<?php echo Form::open(array('url'=>'seguridad/usuario', 'method'=>'GET', 'autocomplete'=>'off', 'role'=>'search')); ?>


<div class="form-group">

    <div class="input-group">

    <input type="search" class="form-control" name="searchtext" placeholder="Buscar.." value="<?php echo e($searchtext); ?>">
    
    <span class="input-group-btn">
        <button type="submit" class="btn btn-primary">Buscar</button>
    </span>

    </div>

</div>

<?php echo e(Form::close()); ?><?php /**PATH C:\laragon\www\Laravel\resources\views/seguridad/usuario/search.blade.php ENDPATH**/ ?>