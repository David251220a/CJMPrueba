

<?php $__env->startSection('contenido'); ?>

    <div class="row">
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <h3>Nueva Planilla</h3>
            
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>
                      
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </ul>

                </div>
                
            <?php endif; ?>
        
        </div>

    </div>

    <div class="rows">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <?php if(session()->has('msj')): ?>
            
            <div class="alert alert-danger" role="alert"><?php echo e(session('msj')); ?></div>
            
            <?php else: ?>
                
            <?php endif; ?>
        </div>
    </div>

    <div class="row">

       
        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

        <div class="form-group">
            <a href="<?php echo e(URL::action('PersonaController@index')); ?>"><button style='width:145px; height:50'  class="btn btn-info">Editar Afiliados</button></a>
        </div>

        </div>    

    </div>

    <?php echo Form::open(array('url'=>'planillamensual/generar', 'method'=>'POST', 'autocomplete'=>'off')); ?>

    <?php echo e(Form::token()); ?>


    <div class="row">

       
        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

        <div class="form-group">

            <button class="btn btn-primary" type="submit">Enviar</button>
            <button class="btn btn-danger" type="reset">Cancelar</button>  
        </div>

        </div>    

    </div>

    <?php  $totalAporte = 0 ?>
    <?php  $totalBonificacion = 0 ?>
    <?php  $TotalAportesinBonificacion = 0 ?>
    <?php  $totalDiferenciaAsif = 0 ?>
    <?php  $totalPrimeraAsif = 0 ?>
    <?php  $totalRSA = 0 ?>
    <?php  $cantidad = 0 ?>
    <?php  $Total_General = 0 ?>
    
    
    <?php $__currentLoopData = $afiliado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $totalAporte += $afi->Aporte  ?>
        <?php $totalDiferenciaAsif += $afi->Diferencia_Asignacion  ?>
        <?php $totalPrimeraAsif += $afi->Primera_Asignacion  ?>
        <?php $totalRSA += $afi->RSA  ?>
        <?php $cantidad +=  1  ?>
        <?php $Total_General += ($afi->Aporte + $afi->Diferencia_Asignacion + $afi->Primera_Asignacion +$afi->RSA) ?>
        <?php if($afi->IdTipo_Aporte == 1): ?>
            

            <?php $TotalAportesinBonificacion += $afi->Aporte  ?>

        <?php else: ?>
            
            <?php $totalBonificacion += $afi->Aporte  ?>

        <?php endif; ?>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="row">

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="fecha" >Fecha de Planilla </label>
                <input type="date" name="fecha" class="form-control" value="2020-01-31">


            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="cantidad" >Cantidad de Afiliados</label>
                <input type="text" name="cantidad" value="<?php echo e($persona->cantidad); ?>" class="form-control" readonly>

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="total_aporte" >Total Aporte </label>
                <input type="text" name="total_aporte" value="<?php echo e($totalAporte); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="total_primera_asig" >Total Primera Asignacion </label>
                <input type="text" name="total_primera_asig" value="<?php echo e($totalPrimeraAsif); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="total_diferencia_asig" >Total Diferencia Asignacion </label>
                <input type="text" name="total_diferencia_asig"  value="<?php echo e($totalDiferenciaAsif); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="total_rsa" >Total R.S.A. </label>
                <input type="text" name="total_rsa"  value="<?php echo e($totalRSA); ?>" class="form-control" readonly>

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="total_aporte_sinboni" >Total Aporte sin Bonificacion </label>
                <input type="text" name="total_aporte_sinboni" value="<?php echo e($TotalAportesinBonificacion); ?>" class="form-control" readonly>

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="total_bonificacion" >Total Bonificacion </label>
                <input type="text" name="total_bonificacion" value="<?php echo e($totalBonificacion); ?>" class="form-control" readonly >

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="total_general" >Total General </label>
                <input type="number" name="total_general" class="form-control" value="<?php echo e($Total_General); ?>" readonly>


            </div>
            
        </div>

    </div>
    
    <div class="rows">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="table-responsive">

                <table class="table table-striped table-bordered table-condensed table-hover">

                    
                    
                    <thead>

                        <th  hidden> Idpersona</th>
                        <th>Cedula de Identidad</th>
                        <th>Nombre</th>                        
                        <th>Apellido</th>
                        <th>Tipo de Aporte</th>
                        <th>Salario</th>
                        <th>Aporte</th>
                        <th>Primera Asig</th>
                        <th>Diferencia Asig</th>
                        <th>RSA</th>
                      

                    </thead>
                    

                    
                        <?php
                        $cont = 0;
                        ?>
                    <?php $__currentLoopData = $afiliado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="select" id="fila<?php echo e($cont); ?>" >
                            <td hidden><input type="hidden" id="idpersona" name="idpersona[]" value="<?php echo e($afi->idpersona); ?>" > </td>
                            <td><input type="text" id="cedula" name="cedula[]" value="<?php echo e($afi->cedula); ?>" readonly></td>
                            <td><input type="text" id="nombre" name="nombre[]" value="<?php echo e($afi->nombre); ?>" readonly></td>                    
                            <td><input type="text"  id="apellido" name="apellido[]" value="<?php echo e($afi->apellido); ?>" readonly></td>
                            <td><input type="hidden" name="idtipo_aporte[]" value="<?php echo e($afi->IdTipo_Aporte); ?>" ><?php echo e($afi->Descripcion); ?></td>
                            <td><input type="number" id="salario" name="salario[]" value="<?php echo e($afi->Salario); ?>" readonly></td>
                            <td><input type="number" id="aporte" name="aporte[]" value="<?php echo e($afi->Aporte); ?>" readonly></td>
                            <td><input type="number" id="primera_asig" name="primera_asig[]"  value="<?php echo e($afi->Primera_Asignacion); ?>" readonly></td>
                            <td><input type="number" id="diferencia_asig" name="diferencia_asig[]"  value="<?php echo e($afi->Diferencia_Asignacion); ?>" readonly></td>
                            <td><input type="number" id="rsa" name="rsa[]" value="<?php echo e($afi->RSA); ?>" readonly></td>
                            
                        </tr>
                        <?php
                        $cont++;
                        ?>
                        <input id="cont" name="cont" value="<?php echo e($cont); ?>" type="hidden"></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                </table>

            </div>


        </div>

    </div>
   
    
    <?php echo Form::close(); ?>


   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/planillamensual/generar/create.blade.php ENDPATH**/ ?>