

<?php $__env->startSection('contenido'); ?>

    <?php if(session()->has('msj')): ?>
    <div class="alert alert-danger" role="alert"><?php echo e(session('msj')); ?></div>
    <?php else: ?>
        
    <?php endif; ?>


    <div class="row">
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <h3>Nueva Planilla de Prestamo</h3>
            
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>
                      
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </ul>

                </div>
                
            <?php endif; ?>
        
        </div>

    </div>

    <?php echo Form::open(array('url'=>'prestamoplanilla/generar', 'method'=>'POST', 'autocomplete'=>'off','file'=>'true', 'enctype'=>"multipart/form-data")); ?>

    <?php echo e(Form::token()); ?>



    <div class="row">

        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

            <div class="form-group">

                <label for="IdInstitucion" >Institucion Municipal</label>
                <select name="IdInstitucion" id="IdInstitucion" class="form-control selectpicker" data-live-search="true" required>

                    <?php $__currentLoopData = $persona; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <option value="<?php echo e($per->id); ?>"><?php echo e($per->name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>
        </div>


        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">

                <label for="excel" >Seleccionar Archivo Excel</label>
                <input type="file" name="excel" class="form-control" required>

            </div>
            
        </div>

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">

            <div class="form-group">
    
                <label for="fecha" >Seleccionar Fecha Planilla</label>
                <input type="date" name="fecha" class="form-control" value="31/01/2020" required>
    
            </div>
            
        </div>

    </div>


    

    <div class="row">

        <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12" id="guardar">

            <div class="form-group">

                <button class="btn btn-primary" type="submit">Enviar</button>
                <button class="btn btn-danger" type="reset">Cancelar</button>  
            </div>

        </div>    

    </div>
    
    <?php echo Form::close(); ?>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/prestamoplanilla/generar/create.blade.php ENDPATH**/ ?>