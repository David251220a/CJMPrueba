

<?php $__env->startSection('contenido'); ?>
    
    <?php echo $__env->make('ayuda.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__currentLoopData = $contenido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="row">

            <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

                <LEGEND><b> <i> <u><h3> <?php echo e($con->Titulo); ?></h3></u></i></b> </LEGEND>
                <label for=""><?php echo e($con->Descripcion); ?> </label>
                <a href="<?php echo e(URL::action('AyudaController@show', $con->IdContenido)); ?>">
                    <button class="btn btn-info ; btn btn-secondary pull-right">Ver</button>
            </a>

            </div>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cjm\resources\views/ayuda/index.blade.php ENDPATH**/ ?>