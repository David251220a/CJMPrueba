<?php return array (
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:qWTZurOM5lQhZWd2rMhcLNI/Tpz8S8TP9NaSQN7T5aU=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
      23 => 'Cohensive\\Embed\\EmbedServiceProvider',
      24 => 'App\\Providers\\AppServiceProvider',
      25 => 'App\\Providers\\AuthServiceProvider',
      26 => 'App\\Providers\\EventServiceProvider',
      27 => 'App\\Providers\\RouteServiceProvider',
      28 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
      'Embed' => 'Cohensive\\Embed\\Facades\\Embed',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
    ),
    'prefix' => 'laravel_cache',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'cjppm_web',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '107.180.12.115',
        'port' => '3306',
        'database' => 'cjppm_web',
        'username' => 'nqqxnvsibikq',
        'password' => 'Paraguay2018!!',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '107.180.12.115',
        'port' => '3306',
        'database' => 'cjppm_web',
        'username' => 'nqqxnvsibikq',
        'password' => 'Paraguay2018!!',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '107.180.12.115',
        'port' => '3306',
        'database' => 'cjppm_web',
        'username' => 'nqqxnvsibikq',
        'password' => 'Paraguay2018!!',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
      ),
    ),
    'links' => 
    array (
      'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\public\\storage' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\app/public',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.mailtrap.io',
        'port' => '2525',
        'encryption' => NULL,
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'auth_mode' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
    ),
    'from' => 
    array (
      'address' => NULL,
      'name' => 'Laravel',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'suffix' => NULL,
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\resources\\views',
    ),
    'compiled' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\framework\\views',
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'orientation' => 'portrait',
    'defines' => 
    array (
      'font_dir' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\fonts/',
      'font_cache' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm\\storage\\fonts/',
      'temp_dir' => 'C:\\Users\\David\\AppData\\Local\\Temp',
      'chroot' => 'E:\\JuegosySofwareinstalado\\laragon\\www\\cjm',
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => true,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => false,
    ),
  ),
  'flare' => 
  array (
    'key' => NULL,
    'reporting' => 
    array (
      'anonymize_ips' => true,
      'collect_git_information' => false,
      'report_queries' => true,
      'maximum_number_of_collected_queries' => 200,
      'report_query_bindings' => true,
      'report_view_data' => true,
      'grouping_type' => NULL,
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'light',
    'enable_share_button' => true,
    'register_commands' => false,
    'ignored_solution_providers' => 
    array (
      0 => 'Facade\\Ignition\\SolutionProviders\\MissingPackageSolutionProvider',
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'transactions' => 
    array (
      'handler' => 'db',
    ),
    'temporary_files' => 
    array (
      'local_path' => 'C:\\Users\\David\\AppData\\Local\\Temp',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
    ),
  ),
  'embed' => 
  array (
    'google_api_key' => 'YOUR API KEY HERE',
    'providers' => 
    array (
      'youtubePlaylistVideo' => 
      array (
        'name' => 'YouTube Playlist',
        'type' => 'video',
        'website' => 'http://youtube.com',
        'ssl' => true,
        'url' => '^(https?://)?(?:www\\.)?(?:youtu\\.be/|youtube\\.com/watch\\?v=)([0-9a-zA-Z-_]{11})(?:\\S*list=)([0-9a-zA-Z-_]+)',
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://youtube.com/watch?v={1}&list={2}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://www.youtube.com/embed/{1}?list={2}&rel=0&wmode=transparent',
            'width' => 560,
            'height' => 315,
            'allowfullscreen' => NULL,
            'frameborder' => 0,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'youtubePlaylist' => 
      array (
        'name' => 'YouTube Playlist',
        'type' => 'video',
        'website' => 'http://youtube.com',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?youtube\\.com/playlist\\?list=([0-9a-zA-Z-_]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://youtube.com/playlist?list={1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://www.youtube.com/embed/videoseries?list={1}&rel=0&wmode=transparent',
            'width' => 560,
            'height' => 315,
            'allowfullscreen' => NULL,
            'frameborder' => 0,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'youtube' => 
      array (
        'name' => 'YouTube',
        'type' => 'video',
        'website' => 'http://youtube.com',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?youtu\\.be/([0-9a-zA-Z-_]{11})?(?:(?:\\S+)?(?:\\?|&)t=([0-9hm]+s))?(?:\\S+)?',
          1 => '^(https?://)?(?:www\\.)?(?:youtu\\.be/|youtube\\.com/(?:embed/|v/|watch\\?v=|watch\\?.+&v=))((?:\\w|-){11})(?:(?:\\S+)?(?:\\?|&)t=([0-9hm]+s))?(?:\\S+)?$',
        ),
        'timestamp' => '^(?:https?://)?(?:www\\.)?(?:youtu\\.be/|youtube\\.com/)(?:\\S+)?(?:(?:\\S+)?(?:\\?|&)t=(?:([0-9]+)h)?(?:([0-9]+)m)?(?:([0-9]+)s)?)$',
        'timestampParam' => '&start=',
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://youtu.be/{1}',
          'dataUrl' => '{protocol}://www.googleapis.com/youtube/v3/videos?part=snippet&id={1}',
          'imageRoot' => '{protocol}://img.youtube.com/vi/{1}/',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://www.youtube.com/embed/{1}?rel=0&wmode=transparent',
            'width' => 560,
            'height' => 315,
            'allowfullscreen' => NULL,
            'frameborder' => 0,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
          'object' => 
          array (
            'attributes' => 
            array (
              'width' => 560,
              'height' => 315,
            ),
            'params' => 
            array (
              'movie' => '{protocol}://youtube.com/v/{1}?version=3&rel=0&wmode=transparent',
              'wMode' => 'transparent',
              'allowFullScreen' => 'true',
              'allowscriptaccess' => 'always',
            ),
            'embed' => 
            array (
              'src' => '{protocol}://youtube.com/v/{1}?version=3&rel=0&wmode=transparent',
              'width' => 560,
              'height' => 315,
              'type' => 'application/x-shockwave-flash',
              'allowFullScreen' => 'true',
              'allowscriptaccess' => 'always',
            ),
          ),
        ),
        'data' => NULL,
        'dataCallback' => 'Cohensive\\Embed\\DataFetcher@fetchYoutube',
      ),
      'liveleak' => 
      array (
        'name' => 'LiveLeak',
        'type' => 'video',
        'website' => 'http://liveleak.com',
        'ssl' => false,
        'url' => '(https?://)?(?:www\\.)?liveleak\\.com/ll_embed\\?f=([0-9a-z]+)',
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://liveleak.com/ll_embed?f={1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://liveleak.com/ll_embed?f={1}',
            'width' => 640,
            'height' => 360,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'vimeo' => 
      array (
        'name' => 'Vimeo',
        'type' => 'video',
        'website' => 'http://vimeo.com',
        'ssl' => true,
        'url' => 
        array (
          0 => '(https?://)?(?:www\\.)?vimeo\\.com/([0-9]+)',
          1 => '(https?://)?(?:www\\.)?vimeo\\.com/m/([0-9]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://vimeo.com/{1}',
          'dataUrl' => '{protocol}://vimeo.com/api/v2/video/{1}.json',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://player.vimeo.com/video/{1}',
            'width' => 500,
            'height' => 281,
            'allowfullscreen' => NULL,
            'frameborder' => 0,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => 'Cohensive\\Embed\\DataFetcher@fetchVimeo',
      ),
      'dailymotion' => 
      array (
        'name' => 'Dailymotion',
        'type' => 'video',
        'website' => 'http://dailymotion.com',
        'ssl' => true,
        'url' => '(https?://)?(?:www\\.)?dailymotion\\.com/video/([^_]+)',
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://dailymotion.com/video/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://www.dailymotion.com/embed/video/{1}',
            'width' => 520,
            'height' => 420,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'gametrailers' => 
      array (
        'name' => 'GameTrailers',
        'type' => 'video',
        'website' => 'http://gametrailers.com',
        'ssl' => false,
        'url' => '^(https?://)?media\\.mtvnservices\\.com/embed/([^"]+:)([0-9a-z-_]+)',
        'info' => 
        array (
          'id' => '{1}{2}',
          'url' => '{protocol}://media.mtvnservices.com/embed/{1}{2}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://media.mtvnservices.com/embed/{1}{2}',
            'width' => 560,
            'height' => 315,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'ign' => 
      array (
        'name' => 'IGN',
        'type' => 'video',
        'website' => 'http://ign.com',
        'ssl' => false,
        'url' => '^(https?://)?(?:www\\.)?ign\\.com/videos/([0-9a-zA-Z-_/]+)',
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://ign.com/videos/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://widgets.ign.com/video/embed/content.html?url={1}',
            'width' => 560,
            'height' => 315,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'vine' => 
      array (
        'name' => 'Vine',
        'type' => 'video',
        'website' => 'http://vine.co',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?vine\\.co/v/([0-9a-zA-Z]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://vine.co/v/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 0.864,
          'iframe' => 
          array (
            'src' => '{protocol}://vine.co/v/{1}/embed/postcard',
            'width' => 600,
            'height' => 600,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'coub' => 
      array (
        'name' => 'Coub',
        'type' => 'video',
        'website' => 'http://coub.com',
        'ssl' => true,
        'url' => '(https?://)?(?:www\\.)?coub\\.com/view/([^_]+)',
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://coub.com/view/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'iframe' => 
          array (
            'src' => '{protocol}://coub.com/embed/{1}?muted=false&autostart=false&originalSize=false&hideTopBar=false',
            'width' => 640,
            'height' => 360,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'kickstarter' => 
      array (
        'name' => 'Kickstarter',
        'type' => 'video',
        'website' => 'http://kickstarter.com',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?kickstarter\\.com/projects/([0-9a-zA-Z-_]+)/([0-9a-zA-Z-_]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://kickstarter.com/projects/{1}/{2}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.33,
          'iframe' => 
          array (
            'src' => '{protocol}://kickstarter.com/projects/{1}/{2}/widget/video.html',
            'scrolling' => 'no',
            'width' => 640,
            'height' => 480,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'ustream' => 
      array (
        'name' => 'Ustream',
        'type' => 'video',
        'website' => 'http://ustream.tv',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?ustream\\.tv/channel/([0-9]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://ustream.tv/channel/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.64,
          'iframe' => 
          array (
            'src' => '{protocol}://ustream.tv/embed/{1}?v3&wmode=direct',
            'scrolling' => 'no',
            'width' => 670,
            'height' => 390,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'ustreamArchive' => 
      array (
        'name' => 'Ustream Recorded',
        'type' => 'video',
        'website' => 'http://ustream.tv',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?ustream\\.tv/recorded/([0-9]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://ustream.tv/recorded/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.64,
          'iframe' => 
          array (
            'src' => '{protocol}://ustream.tv/embed/recorded/{1}?v3&wmode=direct',
            'scrolling' => 'no',
            'width' => 670,
            'height' => 390,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'twitchArchive' => 
      array (
        'name' => 'Twitch Archive',
        'type' => 'video',
        'website' => 'http://twitch.tv',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?twitch\\.tv/([^"]+)/b/([0-9]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://twitch.tv/{1}/b/{2}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.64,
          'object' => 
          array (
            'attributes' => 
            array (
              'type' => 'application/x-shockwave-flash',
              'data' => '{protocol}://twitch.tv/widgets/archive_embed_player.swf',
              'wmode' => 'transparent',
              'id' => 'clip_embed_player_flash',
              'width' => 500,
              'height' => 350,
            ),
            'params' => 
            array (
              'wMode' => 'transparent',
              'allowFullScreen' => 'true',
              'allowScriptAccess' => 'always',
              'allowNetworking' => 'all',
              'flashvars' => 'archive_id={2}&channel={1}&hostname=www.twitch.tv&auto_play=false&start_volume=25',
              'movie' => '{protocol}://www.twitch.tv/widgets/archive_embed_player.swf',
            ),
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'twitchArchiveChapter' => 
      array (
        'name' => 'Twitch Archive',
        'type' => 'video',
        'website' => 'http://twitch.tv',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?twitch\\.tv/([^"]+)/c/([0-9]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://twitch.tv/{1}/c/{2}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.64,
          'object' => 
          array (
            'attributes' => 
            array (
              'type' => 'application/x-shockwave-flash',
              'data' => '{protocol}://twitch.tv/widgets/archive_embed_player.swf',
              'wmode' => 'transparent',
              'id' => 'clip_embed_player_flash',
              'width' => 500,
              'height' => 350,
            ),
            'params' => 
            array (
              'wMode' => 'transparent',
              'allowFullScreen' => 'true',
              'allowScriptAccess' => 'always',
              'allowNetworking' => 'all',
              'flashvars' => 'chapter_id={2}&channel={1}&hostname=www.twitch.tv&auto_play=false&start_volume=25',
              'movie' => '{protocol}://www.twitch.tv/widgets/archive_embed_player.swf',
            ),
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'twitch' => 
      array (
        'name' => 'Twitch',
        'type' => 'video',
        'website' => 'http://twitch.tv',
        'ssl' => true,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?twitch\\.tv/([0-9a-zA-Z-_]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://twitch.tv/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.64,
          'object' => 
          array (
            'attributes' => 
            array (
              'type' => 'application/x-shockwave-flash',
              'data' => '{protocol}://twitch.tv/widgets/live_embed_player.swf?channel={1}',
              'wmode' => 'transparent',
              'id' => 'live_embed_player_flash',
              'width' => 500,
              'height' => 350,
            ),
            'params' => 
            array (
              'allowFullScreen' => 'true',
              'allowScriptAccess' => 'always',
              'allowNetworking' => 'all',
              'flashvars' => 'hostname=www.twitch.tv&channel={1}&auto_play=false&start_volume=25',
              'movie' => '{protocol}://www.twitch.tv/widgets/live_embed_player.swf',
            ),
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'html5video' => 
      array (
        'name' => 'HTML5 video',
        'type' => 'video',
        'website' => '',
        'ssl' => false,
        'url' => 
        array (
          0 => '^(https?://)?(.*).(mp4|ogg|webm)$',
        ),
        'info' => 
        array (
          'id' => '{1}.{2}',
          'url' => '{1}.{2}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.77,
          'video' => 
          array (
            'source' => 
            array (
              0 => 
              array (
                'src' => '{protocol}://{1}.webm',
                'type' => 'video/webm',
              ),
              1 => 
              array (
                'src' => '{protocol}://{1}.ogg',
                'type' => 'video/ogg',
              ),
              2 => 
              array (
                'src' => '{protocol}://{1}.mp4',
                'type' => 'video/mp4',
              ),
            ),
            'width' => 560,
            'height' => 315,
            'controls' => 'controls',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'gfycat' => 
      array (
        'name' => 'gfycat',
        'type' => 'video',
        'website' => 'http://gfycat.com',
        'ssl' => false,
        'url' => 
        array (
          0 => '^(https?://)?(?:www\\.)?gfycat\\.com/([a-zA-Z]+)',
        ),
        'info' => 
        array (
          'id' => '{1}',
          'url' => '{protocol}://gfycat.com/{1}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.64,
          'iframe' => 
          array (
            'src' => '{protocol}://gfycat.com/ifr/{1}',
            'scrolling' => 'no',
            'width' => 670,
            'height' => 390,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
      'web.tv' => 
      array (
        'name' => 'web.tv',
        'type' => 'video',
        'website' => 'http://web.tv',
        'ssl' => false,
        'url' => 
        array (
          0 => '^(https?://)?(\\w+\\.?)?web\\.tv/.*__([a-zA-Z0-9]+)$',
        ),
        'info' => 
        array (
          'id' => '{2}',
          'url' => '{protocol}://{1}web.tv/embed/{2}',
        ),
        'render' => 
        array (
          'sizeRatio' => 1.64,
          'iframe' => 
          array (
            'src' => '{protocol}://{1}web.tv/embed/{2}',
            'scrolling' => 'no',
            'width' => 670,
            'height' => 390,
            'sandbox' => 'allow-scripts allow-same-origin allow-presentation',
            'layout' => 'responsive',
          ),
        ),
        'data' => NULL,
        'dataCallback' => NULL,
      ),
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 30,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
