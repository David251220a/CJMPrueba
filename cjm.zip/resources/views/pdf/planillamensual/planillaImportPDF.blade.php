<div class="rows">
    <h3 style="text-align: center">INSTITUCION DE : {{$planilla->name}}</h3>
    <h4 style="text-align: center"> PLANILLA MENSUAL DE APORTE CON FECHA DE: {{$planilla->Fecha_Planilla}}</h4>

    <br>
</div>